package appointmentschedulingsystem.appointmentschedulingsystem;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class SignupController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;


    // Switch back to login scene
    @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("login");
    }

    // Handle signup logic
    @FXML
    private void handleSignUp() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText();
        String role = "user";

        // Basic validation
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() ) {
            showAlert(AlertType.ERROR, "Form Error!", "Please fill in all fields.");
            return;
        }
        if (UserStorage.findUserByEmail(email) != null) {
            showAlert("Duplicate Email", "This email is already registered.");
            return;
        }
        User newUser = new User(name, email, password, role);
        UserStorage.addUser(newUser);

        showAlert(AlertType.INFORMATION, "Signup Successful", "Welcome, " + name + "!");

        try {
            switchToLogin();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Utility method to show alerts
    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    
    public static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}