package appointmentschedulingsystem.appointmentschedulingsystem;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.io.IOException;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    // Handle login logic
    @FXML
    private void handleLogin() {
        String email = emailField.getText().trim();
        String password = passwordField.getText();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert(AlertType.ERROR, "Login Error", "Please enter both email and password.");
            return;
        }

        User user = UserStorage.findUserByEmail(email);
        if (user == null) {
            showAlert(AlertType.ERROR, "Login Error", "User not found.");
            return;
        }

        if (!user.password.equals(password)) {
            showAlert(AlertType.ERROR, "Login Error", "Incorrect password.");
            return;
        }

        // Login successful
        showAlert(AlertType.INFORMATION, "Login Successful", "Welcome, " + user.fullName + "!");
        try {
            if(user.role.equals("admin")) {
            App.setRoot("admin_dashboard");
        } else {
            
        }
        } catch(IOException e) {
            System.out.println(e);
        }

        // TODO: Load the appropriate dashboard based on user.role
        // e.g., App.setRoot("userDashboard"); or App.setRoot("adminDashboard");
    }

    // Switch to signup screen
    @FXML
    private void switchToSignUp() throws IOException {
        App.setRoot("signup");
    }

    // Utility method for alerts
    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}