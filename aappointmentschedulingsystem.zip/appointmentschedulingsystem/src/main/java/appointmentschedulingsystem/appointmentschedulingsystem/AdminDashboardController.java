package appointmentschedulingsystem.appointmentschedulingsystem;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.IOException;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;

public class AdminDashboardController {

    @FXML
    private TableView<Appointment> appointmentsTable;

    @FXML
    private TableColumn<Appointment, String> dateColumn;

    @FXML
    private TableColumn<Appointment, String> timeColumn;

    @FXML
    private TableColumn<Appointment, String> durationColumn;

    @FXML
    private TableColumn<Appointment, String> participantsColumn;

    @FXML
    private TableColumn<Appointment, String> statusColumn;

    private ObservableList<Appointment> appointmentsList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        // Set up columns
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        durationColumn.setCellValueFactory(new PropertyValueFactory<>("duration"));
        participantsColumn.setCellValueFactory(new PropertyValueFactory<>("participantsCount"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Load initial data
        handleRefresh();
    }

    @FXML
private void handleAddAppointment() {
    // Create the custom dialog
    Dialog<Appointment> dialog = new Dialog<>();
    dialog.setTitle("Add Appointment");
    dialog.setHeaderText("Enter new appointment details");

    // Set the button types
    ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
    dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

    // Create the input fields
    DatePicker datePicker = new DatePicker();
    TextField timeField = new TextField();
    timeField.setPromptText("HH:MM");
    TextField durationField = new TextField();
    durationField.setPromptText("Minutes");
    TextField participantsField = new TextField();
    participantsField.setPromptText("e.g., John, Jane");
    ComboBox<String> statusCombo = new ComboBox<>();
    statusCombo.getItems().addAll("Scheduled", "Completed", "Cancelled");
    statusCombo.setValue("Scheduled");

    // Layout in a grid
    GridPane grid = new GridPane();
    grid.setHgap(10);
    grid.setVgap(10);
    grid.setPadding(new Insets(20, 150, 10, 10));

    grid.add(new Label("Date:"), 0, 0);
    grid.add(datePicker, 1, 0);
    grid.add(new Label("Time:"), 0, 1);
    grid.add(timeField, 1, 1);
    grid.add(new Label("Duration (min):"), 0, 2);
    grid.add(durationField, 1, 2);
    grid.add(new Label("Participants:"), 0, 3);
    grid.add(participantsField, 1, 3);
    grid.add(new Label("Status:"), 0, 4);
    grid.add(statusCombo, 1, 4);

    dialog.getDialogPane().setContent(grid);

    // Enable/disable Add button based on mandatory fields
    Node addButton = dialog.getDialogPane().lookupButton(addButtonType);
    addButton.setDisable(true);

    // Simple validation: date and time must be filled
    datePicker.valueProperty().addListener((obs, oldVal, newVal) -> checkFields(datePicker, timeField, addButton));
    timeField.textProperty().addListener((obs, oldVal, newVal) -> checkFields(datePicker, timeField, addButton));

    // Convert the result to an Appointment object when the Add button is clicked
    dialog.setResultConverter(dialogButton -> {
        if (dialogButton == addButtonType) {
            return new Appointment(
                datePicker.getValue(),
                timeField.getText(),
                durationField.getText(),
                participantsField.getText(),
                statusCombo.getValue()
            );
        }
        return null;
    });

    Optional<Appointment> result = dialog.showAndWait();

    result.ifPresent(appointment -> {
        // TODO: Add appointment to your TableView or backend
        showAlert(Alert.AlertType.INFORMATION, "Appointment Added",
                "Date: " + appointment.getDate() +
                "\nTime: " + appointment.getTime() +
                "\nDuration: " + appointment.getDuration() +
                "\nParticipants: " + appointment.getParticipants() +
                "\nStatus: " + appointment.getStatus());
        appointmentsList.add(appointment);
    });
}

// Simple helper to enable Add button
private void checkFields(DatePicker datePicker, TextField timeField, Node addButton) {
    addButton.setDisable(datePicker.getValue() == null || timeField.getText().trim().isEmpty());
}

    

    @FXML
    private void handleRefresh() {
        // TODO: Load appointments from storage
//        appointmentsList.clear();

        // Example dummy data for now

        appointmentsTable.setItems(appointmentsList);
    }

    @FXML
    private void handleLogout() {
        try {
            App.setRoot("login");
        } catch (IOException e) {
            showAlert(AlertType.ERROR, "Error", "Failed to logout. Please try again.");
            e.printStackTrace();
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}