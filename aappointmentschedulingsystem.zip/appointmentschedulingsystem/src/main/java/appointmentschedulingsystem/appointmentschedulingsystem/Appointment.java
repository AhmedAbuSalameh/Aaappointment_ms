package appointmentschedulingsystem.appointmentschedulingsystem;

import java.time.LocalDate;

public class Appointment {
    private final LocalDate date;
    private final String time;
    private final String duration;
    private final String participants;
    private final String status;

    public Appointment(LocalDate date, String time, String duration, String participants, String status) {
        this.date = date;
        this.time = time;
        this.duration = duration;
        this.participants = participants;
        this.status = status;
    }

    public LocalDate getDate() { return date; }
    public String getTime() { return time; }
    public String getDuration() { return duration; }
    public String getParticipants() { return participants; }
    public String getStatus() { return status; }
}