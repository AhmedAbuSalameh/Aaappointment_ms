module appointmentschedulingsystem.appointmentschedulingsystem {
    requires javafx.controls;
    requires javafx.fxml;

    opens appointmentschedulingsystem.appointmentschedulingsystem to javafx.fxml;
    exports appointmentschedulingsystem.appointmentschedulingsystem;
}
